export default class Translate {

    
}
