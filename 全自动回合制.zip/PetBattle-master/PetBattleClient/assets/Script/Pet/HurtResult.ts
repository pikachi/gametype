export default class HurtResult {
    realHurt: number = 0;
    overFlowHurt: number = 0;
}
