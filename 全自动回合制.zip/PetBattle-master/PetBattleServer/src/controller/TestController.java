package controller;

import pers.jc.mvc.Controller;

@Controller
public class TestController {
	
	public void test(int a) {
		System.out.println(a);
	}
}
